import SwiftUI

@main
struct ClipBoxApp: App {
    var body: some Scene {
        WindowGroup { ContentView() }
    }
}

struct ContentView: View {
    @State private var selectedTab = 0
    var body: some View {
        TabView(selection: $selectedTab) {
            CatalogView(title: "Home", subtitle: "Your films and series")
                .tabItem { Label("Home", systemImage: "house") }.tag(0)
            CatalogView(title: "Movies", subtitle: "Browse movies")
                .tabItem { Label("Movies", systemImage: "film") }.tag(1)
            CatalogView(title: "TV Shows", subtitle: "Browse series")
                .tabItem { Label("TV Shows", systemImage: "tv") }.tag(2)
            CatalogView(title: "My List", subtitle: "Saved for later")
                .tabItem { Label("My List", systemImage: "bookmark") }.tag(3)
            CatalogView(title: "Settings", subtitle: "App preferences")
                .tabItem { Label("Settings", systemImage: "gear") }.tag(4)
        }
        .tint(.red)
        .preferredColorScheme(.dark)
    }
}

struct CatalogView: View {
    let title: String
    let subtitle: String
    var body: some View {
        NavigationStack {
            ZStack {
                Color(red: 0.035, green: 0.04, blue: 0.055).ignoresSafeArea()
                VStack(alignment: .leading, spacing: 18) {
                    VStack(alignment: .leading, spacing: 5) {
                        Text(title).font(.largeTitle.bold())
                        Text(subtitle).foregroundStyle(.secondary)
                    }
                    if title == "Settings" {
                        Label("Playback", systemImage: "play.rectangle")
                        Label("Subtitles", systemImage: "captions.bubble")
                        Label("Profiles", systemImage: "person.2")
                    } else {
                        ContentUnavailableView("Catalog not connected", systemImage: "film.stack", description: Text("The Android APK's catalogue and server integrations still need an iOS implementation. This is the initial iOS project shell."))
                    }
                    Spacer()
                }
                .padding()
            }
            .navigationBarHidden(true)
        }
    }
}
