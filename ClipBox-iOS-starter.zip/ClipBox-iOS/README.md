# ClipBox iOS port — starter project

This is an initial native SwiftUI project shell based on the uploaded APK's visible feature scope. It is **not yet a feature-complete port** and does not contain ClipBox's Android server integrations, catalogue implementation, account backend, subtitle engine, or playback failover logic.

## Build without owning a Mac

1. Create a GitHub repository and upload the contents of this folder.
2. Open **Actions** and run **Build unsigned iOS IPA**.
3. Download the `ClipBox-unsigned-ipa` artifact from the completed workflow.

The workflow uses a GitHub-hosted macOS runner and Xcode. It builds for generic iOS device with code signing disabled, then packages the `.app` into an unsigned `.ipa`.

## Important

An unsigned IPA is not installable until it is signed with a compatible certificate/provisioning profile. Some iOS features require additional entitlements and cannot be enabled by merely signing the file.

## Next engineering work

- Inspect/decompile the APK's app code and document its API/server interfaces.
- Reimplement catalogue and account flows using authorised interfaces.
- Replace Android playback with AVPlayer-compatible HLS/MP4 playback.
- Rebuild subtitles, audio tracks, profiles, history, favourites, parental controls, and playback fallback.
- Validate all server integrations and legal content sources before release.
